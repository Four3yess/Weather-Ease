package com.example.weatherease

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    companion object {
        private const val API_KEY = "YOUR_API_KEY_HERE" // Replace with actual API key
        private const val BASE_URL = "http://api.openweathermap.org/data/2.5/"
    }

    private lateinit var editTextCity: EditText
    private lateinit var buttonGetWeather: Button
    private lateinit var textViewCity: TextView
    private lateinit var textViewTemperature: TextView
    private lateinit var textViewDescription: TextView
    private lateinit var textViewHumidity: TextView

    private lateinit var weatherService: WeatherService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupRetrofit()
        setupClickListener()
    }

    private fun initViews() {
        editTextCity = findViewById(R.id.editTextCity)
        buttonGetWeather = findViewById(R.id.buttonGetWeather)
        textViewCity = findViewById(R.id.textViewCity)
        textViewTemperature = findViewById(R.id.textViewTemperature)
        textViewDescription = findViewById(R.id.textViewDescription)
        textViewHumidity = findViewById(R.id.textViewHumidity)
    }

    private fun setupRetrofit() {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        weatherService = retrofit.create(WeatherService::class.java)
    }

    private fun setupClickListener() {
        buttonGetWeather.setOnClickListener {
            val city = editTextCity.text.toString().trim()
            if (city.isNotEmpty()) {
                getWeatherData(city)
            } else {
                Toast.makeText(this, "Please enter a city name", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getWeatherData(city: String) {
        val call = weatherService.getCurrentWeather(city, API_KEY, "metric")

        call.enqueue(object : Callback<WeatherResponse> {
            override fun onResponse(call: Call<WeatherResponse>, response: Response<WeatherResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    val weather = response.body()!!
                    updateUI(weather)
                } else {
                    Toast.makeText(this@MainActivity, "City not found", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun updateUI(weather: WeatherResponse) {
        textViewCity.text = weather.name
        textViewTemperature.text = "${Math.round(weather.main.temp)}°C"
        textViewDescription.text = weather.weather[0].description
        textViewHumidity.text = "Humidity: ${weather.main.humidity}%"
    }
}